// Script base: potremo aggiungere interazioni, notifiche, o login in seguito
console.log("Sito Condominio Piazza Guala – Via Piobesi attivo");
